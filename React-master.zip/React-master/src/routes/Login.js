import React from 'react';
import NavBar from "../Components/NavBar";
import LCard from "../Components/LCard";
import Footer from '../Components/Footer';

function SignUp(){
    return(
        <>
        <NavBar/>
        <LCard/>
        
        
        </>
    )
}

export default SignUp;