import React from 'react';
import NavBar from "../Components/NavBar";
import SCard from "../Components/SCard";


function SignUp(){
    return(
        <>
        <NavBar/>
        <SCard/>      
        </>
    )
}

export default SignUp;