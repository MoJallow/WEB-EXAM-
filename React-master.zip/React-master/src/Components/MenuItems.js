export const MenuItems = [
    {
        title: "Home",
        url:"/",
        cName: "nav-links"
        
        
    },

    {
        title: "About",
        url:"/about",
        cName: "nav-links"

    },

    {
        title: "Login",
        url:"/login",
        cName: "nav-links",
        
    }
]

